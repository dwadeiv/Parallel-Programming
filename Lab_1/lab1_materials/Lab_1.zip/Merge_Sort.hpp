#ifndef MS_HPP
#define MS_HPP

#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <vector>

using namespace std;

vector<int> mergeVectors(vector<int> vectorA, vector<int> vectorB);
vector<int> mergeSort(vector<int> data);

#endif